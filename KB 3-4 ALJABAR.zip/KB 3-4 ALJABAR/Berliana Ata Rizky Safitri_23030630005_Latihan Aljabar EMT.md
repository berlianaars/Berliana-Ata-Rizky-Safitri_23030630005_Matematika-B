﻿# LATIHAN SOAL ALJABAR
Nama  : Berliana Ata Rizky Safitri


Kelas : Matematika B


NIM   : 23030630005


---

# KB Pekan 3-4: Penggunaan Software EMT untuk Aljabar

---



1. Melakukan operasi bentuk-bentuk Melakukan operasi bentuk-bentuk
aljabar (menjabarkan, menyederhanakan, memfaktorkan, dll.)


2. Melakukan perhitungan dengan berbagai operasi dan fungsi matematika


3. Melakukan perhitungan menggunakan bilangan kompleks


4. Melakukan perhitungan menggunakan fungsi-fungsi buatan sendiri


5. Menyelesaikan persamaan dan sistem persamaan


6. Menyelesaikan pertidaksamaan dan sistem pertidaksamaan


7. Melakukan manipuasi dan perhitungan menggunakan matriks dan vektor


8. Menggunakan aljabar untuk menyelesaikan masalah sehari-hari atau
dalam matematika dan bidang lain.


# R.2 Exercise set

Nomor 49


Menyederhanakan:


$$\left(\frac{24a^{10}b^{-8}c^7}{12a^6b^{-3}c^5}\right)^{-5}$$\>$&((24\*a^(10)\*b^(-8)\*c^7)/(12\*a^6\*b^(-3)\*c^5))^(-5)


$$\frac{b^{25}}{32\,a^{20}\,c^{10}}$$Nomor 50


Menyederhanakan:


$$\left(\frac{125p^{12}q^{-14}r^{22}}{25p^8q^6r^{-15}}\right)^{-4}$$\>$&((125\*p^(12)\*q^(-14)\*r^(22))/25\*p^8\*q^6\*r^(-15))^(-4)


$$\frac{q^{32}}{625\,p^{80}\,r^{28}}$$Nomor 90 


calculate


$$2^6*2^{-3}/2^{10}/2^{-8}$$\>2^6\*2^-3/2^10/2^-8


    2

Nomor 91


Calculate


$$\left(\frac{4(8-6)^2-4*3+2*8}{3^1+9^0}\right)$$\>(4\*(8-6)^2 - 4\*3 + 2\*8)/(3^1+19^0)


    5

Nomor 92


Calculate


$$\left(\frac{[4(8-6)^2-4](3+2*8)}{2^2(2^5+5)}\right)$$\>((4\*(8-6)^2-4)\*3+2\*8)/(3^1+9^0)


    13

# R.3 Exercise Set Perform the indicated operations.

Nomor 27 


$$(x+3)^2$$\>$&showev('expand((x+3)^2))


$${\it expand}\left(\left(x+3\right)^2\right)=x^2+6\,x+9$$Nomor 29


$$(y-5)^2$$\>$&showev('expand((y-5)^2))


$${\it expand}\left(\left(y-5\right)^2\right)=y^2-10\,y+25$$Nomor 33


$$(2x+3y)^2$$\>$&showev('expand((2\*x+3\*y)^2))


$${\it expand}\left(\left(3\,y+2\,x\right)^2\right)=9\,y^2+12\,x\,y+4  \,x^2$$Nomor 39


$$(3y+4)(3y-4)$$\>$&showev('expand((3\*y+4)\*(3\*y-4)))


$${\it expand}\left(\left(3\,y-4\right)\,\left(3\,y+4\right)\right)=9  \,y^2-16$$Nomor 42


$$(3x+5y)(3x-5y)$$\>$&showev('expand ((3\*x + 5\*y)\*(3\*x - 5\*y)))


$${\it expand}\left(\left(3\,x-5\,y\right)\,\left(5\,y+3\,x\right)  \right)=9\,x^2-25\,y^2$$# R.4 Exercise Set Faktor Trinomial

Nomor 24


$$y^2+12y+27$$\>$&solve(y^2+12\*y+27)


$$\left[ y=-9 , y=-3 \right] $$Nomor 23


$$t^2+8t+15$$\>$&solve(t^2+8\*t+15)


$$\left[ t=-3 , t=-5 \right] $$Factor the difference of squares


Nomor 47


$$z^2-81$$\>$&solve(z^2-81)


$$\left[ z=-9 , z=9 \right] $$Nomor 48


$$m^2-4$$\>$&solve(m^2-4)


$$\left[ m=-2 , m=2 \right] $$Nomor 49


$$16x^2-9$$\>$&solve(16\*x^2-9)


$$\left[ x=-\frac{3}{4} , x=\frac{3}{4} \right] $$## R.5 Exercise Set

Nomor 36


Tentukan nilai y


$$y^2-4y-45=0$$\>$&solve(y^2-4\*y-45,y)


$$\left[ y=9 , y=-5 \right] $$Nomor 38


Tentukan nilai y


$$t^2+6t=0$$\>$&solve(t^2+ 6\*t,t)


$$\left[ t=-6 , t=0 \right] $$Nomor 41


tentukan nilai x


$$x^2 + 100 = 20x$$\>$&solve(x^2+100=20\*x,x)


$$\left[ x=10 \right] $$Nomor 42


Tentukan nilai y


$$y^2+25=10y$$\>$&solve(y^2+25=10\*y,y)


$$\left[ y=5 \right] $$Nomor 45


Tentukan nilai y


$$3y^2 + 8y + 4=0$$\>$&solve(3\*y^2 + 8\*y + 4,y)


$$\left[ y=-\frac{2}{3} , y=-2 \right] $$Nomor 47


Tentukan nilai z


$$12z^2+z=6$$\>$&solve(12\*z^2+z=6,z)


$$\left[ z=-\frac{3}{4} , z=\frac{2}{3} \right] $$Nomor 60


Tentukan nilai x


$$5x^2-75=0$$\>$&solve(5\*x^2-75=0,x)


$$\left[ x=-\sqrt{15} , x=\sqrt{15} \right] $$## R.6 Exercise Set

Nomor 9


Menyederhanakan


$$\frac{x^{2}-4}{x^{2}-4x+4}$$\>$&((x^2)/(x^2-4\*x+4)), $&factor(%)


$$\frac{x^2}{\left(x-2\right)^2}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-044.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-044.png)

Nomor 11


Menyederhanakan


$$\frac{x^{3}-6x^{2}+9x}{x^{3}-3x^{2}}$$\>$&((x^3 - 6\*x^2 + 9\*x)/ (x^3 - 3\*x^2)), $&factor(%)


$$\frac{x-3}{x}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-047.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-047.png)

Nomor 14


Menyederhanakan


$$\frac{2x^{2}-20x+50}{10x^{2}-30x-100}$$\>$&((2\*x^2-20\*x+50)/(10\*x^2-30\*x-100)), $&factor(%)


$$\frac{x-5}{5\,\left(x+2\right)}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-050.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-050.png)

Nomor 15


Menyederhanakan


$$\frac{4-x}{x^{2}+4x-32}$$\>$&((4-x)/(x^2 +4\*x-32)), $&factor(%)


$$-\frac{1}{x+8}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-053.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-053.png)

Nomor 16


Menyederhanakan


$$\frac{6-x}{x^{2}-36}$$\>$&((6-x)/(x^2-36)), $&factor(%)


$$-\frac{1}{x+6}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-056.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-056.png)

Nomor 23


$$\frac{m^2 - n^2}{\left(s + \frac{m - n}{r}\right)(s + r)}$$\>$&(((m^2-n^2)/(r+s))/((m-n)/r+s)), $&factor(%)


$$\frac{\left(m-n\right)\,\left(n+m\right)\,r}{\left(s+r\right)\,  \left(r\,s-n+m\right)}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-059.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-059.png)

Nomor 25


$$\frac{(x - 4)^2 (3x + 12)}{(x + 4)^2 (2x - 8)}$$\>$&(((3\*x+12)/(2\*x-8))/(((x+4)^2)/(x-4)^2)), $&factor(%)


$$\frac{3\,\left(x-4\right)}{2\,\left(x+4\right)}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-062.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-062.png)

Nomor 28


$$\frac{(c^2 - 4c + 4)(c^3 + 8)}{(c^2 - 4)(c^2 - 2c + 4)(c - 2)}$$\>$&(((c^3+8)/(c^2-4)) /((c^2 -2\*c +4)/(c^2-4\*c+4))), $&factor(%) 


$$c-2$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-065.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-065.png)

# REVIEW Multiply

Nomor 73


$$(a^n-b^n)^x$$\>function P(a,b,n,x) &= (a^n - b^n)^x; $&P(a,b,n,x)


$$\left(a^{n}-b^{n}\right)^{x}$$\>$&P(a,b,n,3), $&expand(%)


$$-b^{3\,n}+3\,a^{n}\,b^{2\,n}-3\,a^{2\,n}\,b^{n}+a^{3\,n}$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-069.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-069.png)

Nomor 71


\>function P(a,n) &= (t^a+t^(-a))^n; $&P(a,n)


$$\left(t^{a}+\frac{1}{t^{a}}\right)^{n}$$\>$&P(a,2), $&expand(%)


$$t^{2\,a}+\frac{1}{t^{2\,a}}+2$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-072.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-072.png)

Soal 39


\>$&solve(9\*x^2-30\*x+25,x)


$$\left[ x=\frac{5}{3} \right] $$soal nomor 41


\>$&solve(18\*x^2-3\*x+6,x)


$$\left[ x=\frac{1-\sqrt{47}\,i}{12} , x=\frac{\sqrt{47}\,i+1}{12}   \right] $$soal nomor 48


\>$&solve((8-3\*x)=(-7+2\*x),x)


$$\left[ x=3 \right] $$soal nomor 70


\>$& '((x^n+10)\*(x^n-4)) = expand(((x^n+10)\*(x^n-4)))


$$\left(x^{n}-4\right)\,\left(x^{n}+10\right)=x^{2\,n}+6\,x^{n}-40$$soal nomor 71


\>$& '((t^a+t^(-a))^2) = expand(((t^a+t^(-a))^2))


$$\left(t^{a}+\frac{1}{t^{a}}\right)^2=t^{2\,a}+\frac{1}{t^{2\,a}}+2$$soal nomor 72


\>$& '((y^b-z^c)\*(y^b+z^c)) = expand((y^b-z^c)\*(y^b+z^c))


$$\left(y^{b}-z^{c}\right)\,\left(z^{c}+y^{b}\right)=y^{2\,b}-z^{2\,c  }$$soal nomor 73


\>$& '((a^n-b^n)^3) = expand((a^n-b^n)^3)


$$\left(a^{n}-b^{n}\right)^3=-b^{3\,n}+3\,a^{n}\,b^{2\,n}-3\,a^{2\,n}  \,b^{n}+a^{3\,n}$$soal chapter R test nomor 32


\>$& '(((x^2+x-6)/(x^2+8\*x+15))\*((x^2-25)/(x^2-4\*x+4))) = simplify(((x^2+x-6)/(x^2+8\*x+15))\*((x^2-25)/(x^2-4\*x+4)))


$$\frac{\left(x^2-25\right)\,\left(x^2+x-6\right)}{\left(x^2-4\,x+4  \right)\,\left(x^2+8\,x+15\right)}={\it simplify}\left(\frac{\left(x  ^2-25\right)\,\left(x^2+x-6\right)}{\left(x^2-4\,x+4\right)\,\left(x  ^2+8\,x+15\right)}\right)$$\>$&solve(((x^2+x-6)/(x^2+8\*x+15))\*((x^2-25)/(x^2-4\*x+4)),x)


$$\left[ x=5 \right] $$soal nomor 33


\>$& '(((x)/(x^2-1))-((3)/(x^2+4\*x-5)))=simplify(((x)/(x^2-1))-((3)/(x^2+4\*x-5)))


$$\frac{x}{x^2-1}-\frac{3}{x^2+4\,x-5}={\it simplify}\left(\frac{x}{x  ^2-1}-\frac{3}{x^2+4\,x-5}\right)$$\>$&solve(((x)/(x^2-1))-((3)/(x^2+4\*x-5)))


$$\left[ x=-3 \right] $$# 2.3 Exercise Set

Cari


$$\left(f\circ g\right)\left(x\right) dan \left(g\circ f\right)\left(x\right)$$

dan domain nya !


$$1. f(x)=x+3\ ,\ g(x)=x-3$$$$\left(f\circ g\right)\left(x\right)=$$\>$&gx:=x-3; $&fx:=gx+3; $&fx


$$x$$dengan domainnya


$$D_{f\circ g}=\left\{x\in\mathbb{R}\right\}$$$$\left(g\circ f\right)\left(x\right)=$$\>$&fx:=x+3; $&gx:=fx-3; $&gx


$$x$$dengan domainnya


$$D_{g\circ f}=\left\{x\in\mathbb{R}\right\}$$$$2. f(x)=4/(1-5x)\ \ ,\ g(x)=1/x$$$$\left(f\circ g\right)\left(x\right)=$$\>$&gx:=1/x; $&fx:=4/(1-5\*gx); $&fx


$$\frac{4}{1-\frac{5}{x}}$$dengan domain


$$D_{f\circ g}=\left\{x\in\mathbb{R}|x\neq 0\cup x\neq 5\right\}$$$$\left(g\circ f\right)\left(x\right)=$$\>$&fx:=4/(1-5\*x); $&gx:=1/fx; $&gx


$$\frac{1-5\,x}{4}$$dengan domainnya


$$D_{g\circ f}=\left\{x\in\mathbb{R}\right\}$$Diberikan fungsi


$$f(x)=3x+1 , g(x)=x^2-2x-6 , h(x)=x^3$$cari


$$3.\ \left(f\circ g\right)\left(1/3\right)$$\>$x:=1/3; $&gx:=x^2-2\*x-6; $&fx:=3\*gx+1; $&fx


$$-\frac{56}{3}$$$$4. \left(g\circ h\right)\left(1/2\right)$$\>$x:=1/2; $&hx:=x^3; $&gx:=hx^2-2\*hx-6; $&gx


$$-\frac{399}{64}$$$$5. \left(g\circ g\right)\left(-2\right)$$\>$x:=-2; $&gx:=x^2-2\*x-6; $&gx:=gx^2-2\*gx-6; $&gx


$$-6$$# 3.1 Exercise Set Use the quadratic formula to find exact solutions

\>$&solve(x^2-2= 15,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^2-2= 15,x) ...
                        ^

Nomor 39


$$5m^2+3m=2$$\>$&solve(5\*m^2+3\*m=2,m)


$$\left[ m=\frac{2}{5} , m=-1 \right] $$Nomor 40


$$2y^2-3y-2=0$$\>$&solve(2\*y^2-3\*y-2=0,y)


$$\left[ y=-\frac{1}{2} , y=2 \right] $$Solve.


Nomor 83


$$y^4+4y^2-5=0$$\>$&solve(y^4+4\*y^2-5=0,y)


$$\left[ y=-1 , y=1 , y=-\sqrt{5}\,i , y=\sqrt{5}\,i \right] $$Nomor 84


$$y^4-15y^2-16=0$$\>$&solve(y^4-15\*y^2-16=0,y)


$$\left[ y=-i , y=i , y=-4 , y=4 \right] $$# 3.4 Exercise Set Solve

Nomor 1


\>$&solve(1/4+1/5=1/t,t)


$$\left[ t=\frac{20}{9} \right] $$Nomor 6


\>$&solve(1/t+1/2\*t+1/3\*t=5,t)


$$\left[ t=\frac{15-\sqrt{195}}{5} , t=\frac{\sqrt{195}+15}{5}   \right] $$Nomor 18


\>$&solve(3\*y+5/y^2+5\*y +y+4/y+5=y+1/y,y)


$$\left[ y=-\frac{47\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)  }{576\,\left(\frac{\sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{  13824}\right)^{\frac{1}{3}}}+\left(\frac{\sqrt{35539}}{128\,3^{  \frac{3}{2}}}-\frac{3905}{13824}\right)^{\frac{1}{3}}\,\left(-\frac{  \sqrt{3}\,i}{2}-\frac{1}{2}\right)-\frac{5}{24} , y=\left(\frac{  \sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{13824}\right)^{  \frac{1}{3}}\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)-\frac{  47\,\left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)}{576\,\left(  \frac{\sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{13824}\right)  ^{\frac{1}{3}}}-\frac{5}{24} , y=\left(\frac{\sqrt{35539}}{128\,3^{  \frac{3}{2}}}-\frac{3905}{13824}\right)^{\frac{1}{3}}-\frac{47}{576  \,\left(\frac{\sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{13824}  \right)^{\frac{1}{3}}}-\frac{5}{24} \right] $$# 3.5 Exercise Set

\>&load(fourier\_elim)


    
            C:/Program Files/Euler x64/maxima/share/maxima/5.35.1/share/f\
    ourier_elim/fourier_elim.lisp
    

Nomor 23


\>$&(abs(x+3)-2=8)


$$\left| x+3\right| -2=8$$\>$&solve(abs(x+3)-2=8)


$$\left[ \left| x+3\right| =10 \right] $$Nomor 24


\>$&(abs(x-4)+3=9)


$$\left| x-4\right| +3=9$$\>$&solve(abs(x-4)+3=9)


$$\left[ \left| x-4\right| =6 \right] $$Nomor 25


\>$&(abs(3\*x+1)-4=-1)


$$\left| 3\,x+1\right| -4=-1$$\>$&solve(abs(3\*x+1)-4=-1)


$$\left[ \left| 3\,x+1\right| =3 \right] $$Nomor 30


\>$&(9-abs(x-2)=7)


$$9-\left| x-2\right| =7$$\>$&solve(9-abs(x-2)=7)


$$\left[ \left| x-2\right| =2 \right] $$Nomor 32


\>$&(5-abs(4\*x+3)=2)


$$5-\left| 4\,x+3\right| =2$$\>$&solve(5-abs(4\*x+3)=2)


$$\left[ \left| 4\,x+3\right| =3 \right] $$# Chapter 3 Test

Nomor 8


\>$&solve(3/3\*x+4 + 2/x-1 =2,x)


$$\left[ x=\frac{-\sqrt{7}\,i-1}{2} , x=\frac{\sqrt{7}\,i-1}{2}   \right] $$\>$load(fourier\_elim)


Nomor 11


\>$&fourier\_elim([x+4]=7,[x])//x+4=7


$$\left[ \left[ x-3 \right] =0 \right] $$Nomor 12


\>$&fourier\_elim([4\*y-3]=5,[x])//4\*y-3=5


$$\left[ \left[ 4\,\left(y-2\right) \right] =0 \right] $$Solve


Nomor 13


\>$&fourier\_elim([x+3]<=4,[x])//x+3<=4


$$\left[ \left[ x-1 \right] =0 \right] \lor \left[ \left[ 1-x   \right] >0 \right] $$Nomor 15


\>$&fourier\_elim([x+5]\>2,[x])//x+5\>2


$$\left[ \left[ x+3 \right] >0 \right] $$# 4.1 Exercise Set

Use the substitution to determine whether 2,3 and -1 are zeros of


Nomor 23


\>function P(x) &= (x^3-9\*x^2+14\*x+24); $&P(x)


$$-48$$\>P(4)


    -48

\>P(5)


    -48

\>P(-2)


    -48

Jadi hasil substitusi yang menghasilkan persamaan mempunyai nilai nol
adalah dengan mensubtsisusi angka 4


Nomor 24


\>function P(x) &= (2\*x^3-3\*x^2+x+6);$&P(x)


$$-24$$\>P(2)


    -24

\>P(3)


    -24

\>P(-1)


    -24

Jadi hasil substitusi yang menghasilkan persamaan mempunyai nilai nol
adalah dengan mensubtsisusi angka -1


Nomor 25


\>function P(x) &= (x^4-6\*x^3+8\*x^2+6\*x-9);$&P(x)


$$75$$\>P(2)


    75

\>P(3)


    75

\>P(-1)


    75

Jadi hasil substitusi yang menghasilkan persamaan mempunyai nilai nol
adalah dengan mensubtsisusi angka 3 dan -1


# 4.3 Exercise Set

Nomor 1


For the function


$$f(x)= x^4-6x^3+x^2+24x-20$$

use long division to determine whether each of the following is a
factor of f(x)


a) x+1


b) x-2


c) x + 5


\>function f(x) &= (x^4-6\*x^3+x^2+24\*x-20);$&f(x)


$$x^4-6\,x^3+x^2+24\,x-20$$\>$&f(x+1), $&expand(%)


$$x^4-2\,x^3-11\,x^2+12\,x$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-138.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-138.png)

\>$&f(x-2), $&expand(%)


$$x^4-14\,x^3+61\,x^2-84\,x$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-140.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-140.png)

\>$&f(x+5), $&expand(%)


$$x^4+14\,x^3+61\,x^2+84\,x$$![images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-142.png](images/Berliana%20Ata%20Rizky%20Safitri_23030630005_Latihan%20Aljabar%20EMT-142.png)

Nomor 23


Use synthetic division to find the function values.


$$f(x) = x^3-6x^2+11x-6$$

find f(1), f(-2), dan f(3)


\>function f(x) &= (x^3-6\*x^2+11\*x-6);$&f(x)


$$x^3-6\,x^2+11\,x-6$$\>f(1)


    0

\>f(-2)


    -60

\>f(3)


    -60

Nomor 24




find f(-3),f(-2), dan f(1)


\>function f(x) &= (x^3+7\*x^2-12\*x-3);$&f(x)


$$41$$\>f(-3)


    41

\>f(-2)


    41

\>f(1)


    41

Nomor 25


$$f(x) = x^4-3x^2+2x+8 $$

find f(-1),f(4) dan f(-5)


\>function f(x) &= (x^4-3\*x^3+2\*x+8);$&f(x)


$$44$$\>f(-1)


    44

\>f(4)


    44

\>f(-5)


    44

Factor the polynomial function f(x). Then Solve the equation f(x)=0


Nomor 39


$$f(x)=x^3+4x^2+x-6$$\>fx &= (x^3+4\*x^2+x-6=0); $&fx


$$x^3+4\,x^2+x-6=0$$\>$&factor((fx,x^3+4\*x^2+x-6=0))


$$\left(x-1\right)\,\left(x+2\right)\,\left(x+3\right)=0$$Nomor 40


$$f(x)=x^3+5x^2-2x-24$$\>fx &= (x^3+5\*x^2-2\*x-24=0); $&fx


$$x^3+5\,x^2-2\,x-24=0$$\>$&factor((fx,x^3+5\*x^2-2\*x-24=0))


$$\left(x-2\right)\,\left(x+3\right)\,\left(x+4\right)=0$$# Mid-Chapter Mixed Review Use synthetic division to find the function

values


Nomor 18


$$g(x) = x^3-9x^2+4x-10$$

find g(-5)


\>function g(x) &= (x^3-9\*x^2+4\*x-10);$&g(x)


$$x^3-9\,x^2+4\,x-10$$\>g(-5)


    -380

Nomor 19


$$f(x)=20x^2-40x$$

find f(1/2)


\>function f(x) &= (20\*x^2-40\*x);$&f(x)


$$20\,x^2-40\,x$$\>f(1/2)


    -15

Using synthetic division, determine whether the numbers are zeros of
the polynomial function.


Nomor 22


-1,5;


$$f(x)=x^6-35x^4+259x^2-225$$\>function f(x) &= (x^6-35\*x^4+259\*x^2-225);$&f(x)


$$x^6-35\,x^4+259\,x^2-225$$\>f(-1.5)


    191.953125

Factor the polynomial function f(x). Then solve the equation f(x) =0.


Nomor 23


$$h(x) = x^3-2x^2-55x+56$$\>hx &= (x^3-2\*x^2-55\*x+56=0); $&hx


$$x^3-2\,x^2-55\,x+56=0$$\>$&factor((hx,x^3-2\*x^2-55\*x+56=0))


$$\left(x-8\right)\,\left(x-1\right)\,\left(x+7\right)=0$$Nomor 24


$$g(x) = x^4-2x^3-13x^2+14x+24$$\>gx &= (x^4-2\*x^3-13\*x^2+14\*x+24=0); $&gx


$$x^4-2\,x^3-13\,x^2+14\,x+24=0$$\>$&factor((gx,x^4-2\*x^3-13\*x^2+14\*x+24=0))


$$\left(x-4\right)\,\left(x-2\right)\,\left(x+1\right)\,\left(x+3  \right)=0$$